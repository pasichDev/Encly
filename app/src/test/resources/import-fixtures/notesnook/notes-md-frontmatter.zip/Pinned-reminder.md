---
title: "Pinned reminder"
created_at: 14-10-2026 10:50 PM
updated_at: 14-10-2026 10:50 PM
pinned: true
tags: 
---

# Pinned reminder

Water the plants.

