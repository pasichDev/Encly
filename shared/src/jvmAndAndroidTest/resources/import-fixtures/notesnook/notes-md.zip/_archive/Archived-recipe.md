# Archived recipe

Flour, water, salt.

