# Groceries

- [x] Milk

- [ ] Eggs

- [ ] Хліб 🍞

