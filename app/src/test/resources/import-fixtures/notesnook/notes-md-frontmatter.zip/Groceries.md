---
title: "Groceries"
created_at: 14-10-2026 10:47 PM
updated_at: 14-10-2026 10:48 PM
tags: home
---

# Groceries

- [x] Milk

- [ ] Eggs

- [ ] Хліб 🍞

