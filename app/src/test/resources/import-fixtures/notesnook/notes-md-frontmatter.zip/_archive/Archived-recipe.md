---
title: "Archived recipe"
created_at: 14-10-2026 10:49 PM
updated_at: 14-10-2026 10:49 PM
archived: true
tags: 
---

# Archived recipe

Flour, water, salt.

