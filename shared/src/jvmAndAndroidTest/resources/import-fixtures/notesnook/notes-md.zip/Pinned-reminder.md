# Pinned reminder

Water the plants.

